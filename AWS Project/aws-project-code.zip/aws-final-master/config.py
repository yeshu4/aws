customhost = "database-1.coghw13fheqo.us-east-2.rds.amazonaws.com"
customuser = "root"
custompass = "root1234"
customdb = "employee"
custombucket = "addemp-1"
customregion = "us-east-2"

